create view sf_g as
select `xscj`.`student`.`学号` AS `学号`, avg(`xscj`.`stucourse`.`成绩`) AS `平均成绩`
from (`xscj`.`student`
         join `xscj`.`stucourse` on ((`xscj`.`student`.`学号` = `xscj`.`stucourse`.`学号`)))
where (`xscj`.`student`.`性别` = '女')
group by `xscj`.`student`.`学号`;

