create view total as
select `xscj`.`student`.`学号`   AS `学号`,
       `xscj`.`student`.`姓名`   AS `姓名`,
       `xscj`.`course`.`课程号`   AS `课程号`,
       `xscj`.`course`.`课程名`   AS `课程名`,
       `xscj`.`stucourse`.`成绩` AS `成绩`
from (`xscj`.`student`
         join (`xscj`.`course` join `xscj`.`stucourse` on ((`xscj`.`course`.`课程号` = `xscj`.`stucourse`.`课程号`)))
              on ((`xscj`.`student`.`学号` = `xscj`.`stucourse`.`学号`)))
order by `xscj`.`student`.`学号`;

