create view vmmax as
select `xscj`.`total`.`sno` AS `sno`, max(`xscj`.`total`.`grade`) AS `maxgrade`
from `xscj`.`total`
group by `xscj`.`total`.`sno`;

